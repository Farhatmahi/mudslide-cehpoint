(self.webpackChunk_N_E=self.webpackChunk_N_E||[]).push([[455],{6008:function(e,t,a){(window.__NEXT_P=window.__NEXT_P||[]).push(["/contact-us",function(){return a(3110)}])},6675:function(e,t,a){"use strict";var s=a(5893),r=a(7285);let i=()=>(0,s.jsx)(r.E.div,{initial:{opacity:0},animate:{opacity:1},transition:{duration:1,delay:1},exit:{opacity:0},className:"bg-[#2B2C7F] relative z-10",children:(0,s.jsxs)("div",{className:"container mx-auto px-4 flex flex-col lg:flex-row justify-between items-center py-4 lg:py-0 lg:h-[7vh]",children:[(0,s.jsx)("p",{className:"text-white py-0 lg:py-4",children:"\xa9 Mudslide Creators Hub Pvt Ltd"}),(0,s.jsxs)("div",{className:"flex items-center justify-center",children:[(0,s.jsx)("a",{href:"/contact-us",children:(0,s.jsx)("p",{className:"text-white mr-6",children:"contact"})}),(0,s.jsx)("p",{className:"text-white mr-6",children:"|"}),(0,s.jsx)("a",{href:"https://quikey.app",target:"_blank",children:(0,s.jsx)("p",{className:"text-white",children:"quikey"})})]})]})});t.Z=i},2264:function(e,t,a){"use strict";var s=a(5893),r=a(7285);let i=()=>(0,s.jsx)(r.E.div,{initial:{opacity:0},animate:{opacity:1},exit:{opacity:0},className:"bg-gradient-to-r from-gray-300 to-[#FF6805] h-[10vh] flex justify-start items-center",children:(0,s.jsxs)("div",{className:"flex justify-start items-center container mx-auto px-4 md:px-0",children:[(0,s.jsx)("img",{src:"/image/ezgif.com-crop.png",className:"w-[100px] h-[100px] mr-4 mt-4",alt:""}),(0,s.jsxs)("p",{className:"text-[#2B2C7F] text-[14px] font-medium",children:[(0,s.jsx)("span",{className:"font-semibold text-[24px] leading-6",children:"Mudslide"}),(0,s.jsx)("br",{}),(0,s.jsx)("span",{className:"tracking-widest",children:"Creators Hub"})]})]})});t.Z=i},3110:function(e,t,a){"use strict";let s,r;a.r(t),a.d(t,{default:function(){return ee}});var i,o=a(5893),n=a(6675),l=a(2264),c=a(7285),d=a(7294);let m={data:""},p=e=>"object"==typeof window?((e?e.querySelector("#_goober"):window._goober)||Object.assign((e||document.head).appendChild(document.createElement("style")),{innerHTML:" ",id:"_goober"})).firstChild:e||m,x=/(?:([\u0080-\uFFFF\w-%@]+) *:? *([^{;]+?);|([^;}{]*?) *{)|(}\s*)/g,u=/\/\*[^]*?\*\/|  +/g,f=/\n+/g,h=(e,t)=>{let a="",s="",r="";for(let i in e){let o=e[i];"@"==i[0]?"i"==i[1]?a=i+" "+o+";":s+="f"==i[1]?h(o,i):i+"{"+h(o,"k"==i[1]?"":t)+"}":"object"==typeof o?s+=h(o,t?t.replace(/([^,])+/g,e=>i.replace(/(^:.*)|([^,])+/g,t=>/&/.test(t)?t.replace(/&/g,e):e?e+" "+t:t)):i):null!=o&&(i=/^--/.test(i)?i:i.replace(/[A-Z]/g,"-$&").toLowerCase(),r+=h.p?h.p(i,o):i+":"+o+";")}return a+(t&&r?t+"{"+r+"}":r)+s},g={},b=e=>{if("object"==typeof e){let t="";for(let a in e)t+=a+b(e[a]);return t}return e},y=(e,t,a,s,r)=>{var i,o;let n=b(e),l=g[n]||(g[n]=(e=>{let t=0,a=11;for(;t<e.length;)a=101*a+e.charCodeAt(t++)>>>0;return"go"+a})(n));if(!g[l]){let t=n!==e?e:(e=>{let t,a,s=[{}];for(;t=x.exec(e.replace(u,""));)t[4]?s.shift():t[3]?(a=t[3].replace(f," ").trim(),s.unshift(s[0][a]=s[0][a]||{})):s[0][t[1]]=t[2].replace(f," ").trim();return s[0]})(e);g[l]=h(r?{["@keyframes "+l]:t}:t,a?"":"."+l)}let c=a&&g.g?g.g:null;return a&&(g.g=g[l]),i=g[l],o=t,c?o.data=o.data.replace(c,i):-1===o.data.indexOf(i)&&(o.data=s?i+o.data:o.data+i),l},j=(e,t,a)=>e.reduce((e,s,r)=>{let i=t[r];if(i&&i.call){let e=i(a),t=e&&e.props&&e.props.className||/^go/.test(e)&&e;i=t?"."+t:e&&"object"==typeof e?e.props?"":h(e,""):!1===e?"":e}return e+s+(null==i?"":i)},"");function N(e){let t=this||{},a=e.call?e(t.p):e;return y(a.unshift?a.raw?j(a,[].slice.call(arguments,1),t.p):a.reduce((e,a)=>Object.assign(e,a&&a.call?a(t.p):a),{}):a,p(t.target),t.g,t.o,t.k)}N.bind({g:1});let w,v,k,E=N.bind({k:1});function C(e,t){let a=this||{};return function(){let s=arguments;function r(i,o){let n=Object.assign({},i),l=n.className||r.className;a.p=Object.assign({theme:v&&v()},n),a.o=/ *go\d+/.test(l),n.className=N.apply(a,s)+(l?" "+l:""),t&&(n.ref=o);let c=e;return e[0]&&(c=n.as||e,delete n.as),k&&c[0]&&k(n),w(c,n)}return t?t(r):r}}var $=e=>"function"==typeof e,_=(e,t)=>$(e)?e(t):e,F=(s=0,()=>(++s).toString()),z=()=>{if(void 0===r&&"u">typeof window){let e=matchMedia("(prefers-reduced-motion: reduce)");r=!e||e.matches}return r},q=new Map,O=e=>{if(q.has(e))return;let t=setTimeout(()=>{q.delete(e),M({type:4,toastId:e})},1e3);q.set(e,t)},S=e=>{let t=q.get(e);t&&clearTimeout(t)},A=(e,t)=>{switch(t.type){case 0:return{...e,toasts:[t.toast,...e.toasts].slice(0,20)};case 1:return t.toast.id&&S(t.toast.id),{...e,toasts:e.toasts.map(e=>e.id===t.toast.id?{...e,...t.toast}:e)};case 2:let{toast:a}=t;return e.toasts.find(e=>e.id===a.id)?A(e,{type:1,toast:a}):A(e,{type:0,toast:a});case 3:let{toastId:s}=t;return s?O(s):e.toasts.forEach(e=>{O(e.id)}),{...e,toasts:e.toasts.map(e=>e.id===s||void 0===s?{...e,visible:!1}:e)};case 4:return void 0===t.toastId?{...e,toasts:[]}:{...e,toasts:e.toasts.filter(e=>e.id!==t.toastId)};case 5:return{...e,pausedAt:t.time};case 6:let r=t.time-(e.pausedAt||0);return{...e,pausedAt:void 0,toasts:e.toasts.map(e=>({...e,pauseDuration:e.pauseDuration+r}))}}},T=[],I={toasts:[],pausedAt:void 0},M=e=>{I=A(I,e),T.forEach(e=>{e(I)})},P=(e,t="blank",a)=>({createdAt:Date.now(),visible:!0,type:t,ariaProps:{role:"status","aria-live":"polite"},message:e,pauseDuration:0,...a,id:(null==a?void 0:a.id)||F()}),D=e=>(t,a)=>{let s=P(t,e,a);return M({type:2,toast:s}),s.id},Z=(e,t)=>D("blank")(e,t);Z.error=D("error"),Z.success=D("success"),Z.loading=D("loading"),Z.custom=D("custom"),Z.dismiss=e=>{M({type:3,toastId:e})},Z.remove=e=>M({type:4,toastId:e}),Z.promise=(e,t,a)=>{let s=Z.loading(t.loading,{...a,...null==a?void 0:a.loading});return e.then(e=>(Z.success(_(t.success,e),{id:s,...a,...null==a?void 0:a.success}),e)).catch(e=>{Z.error(_(t.error,e),{id:s,...a,...null==a?void 0:a.error})}),e};var B=C("div")`
  width: 20px;
  opacity: 0;
  height: 20px;
  border-radius: 10px;
  background: ${e=>e.primary||"#ff4b4b"};
  position: relative;
  transform: rotate(45deg);

  animation: ${E`
from {
  transform: scale(0) rotate(45deg);
	opacity: 0;
}
to {
 transform: scale(1) rotate(45deg);
  opacity: 1;
}`} 0.3s cubic-bezier(0.175, 0.885, 0.32, 1.275)
    forwards;
  animation-delay: 100ms;

  &:after,
  &:before {
    content: '';
    animation: ${E`
from {
  transform: scale(0);
  opacity: 0;
}
to {
  transform: scale(1);
  opacity: 1;
}`} 0.15s ease-out forwards;
    animation-delay: 150ms;
    position: absolute;
    border-radius: 3px;
    opacity: 0;
    background: ${e=>e.secondary||"#fff"};
    bottom: 9px;
    left: 4px;
    height: 2px;
    width: 12px;
  }

  &:before {
    animation: ${E`
from {
  transform: scale(0) rotate(90deg);
	opacity: 0;
}
to {
  transform: scale(1) rotate(90deg);
	opacity: 1;
}`} 0.15s ease-out forwards;
    animation-delay: 180ms;
    transform: rotate(90deg);
  }
`,L=C("div")`
  width: 12px;
  height: 12px;
  box-sizing: border-box;
  border: 2px solid;
  border-radius: 100%;
  border-color: ${e=>e.secondary||"#e0e0e0"};
  border-right-color: ${e=>e.primary||"#616161"};
  animation: ${E`
  from {
    transform: rotate(0deg);
  }
  to {
    transform: rotate(360deg);
  }
`} 1s linear infinite;
`,H=C("div")`
  width: 20px;
  opacity: 0;
  height: 20px;
  border-radius: 10px;
  background: ${e=>e.primary||"#61d345"};
  position: relative;
  transform: rotate(45deg);

  animation: ${E`
from {
  transform: scale(0) rotate(45deg);
	opacity: 0;
}
to {
  transform: scale(1) rotate(45deg);
	opacity: 1;
}`} 0.3s cubic-bezier(0.175, 0.885, 0.32, 1.275)
    forwards;
  animation-delay: 100ms;
  &:after {
    content: '';
    box-sizing: border-box;
    animation: ${E`
0% {
	height: 0;
	width: 0;
	opacity: 0;
}
40% {
  height: 0;
	width: 6px;
	opacity: 1;
}
100% {
  opacity: 1;
  height: 10px;
}`} 0.2s ease-out forwards;
    opacity: 0;
    animation-delay: 200ms;
    position: absolute;
    border-right: 2px solid;
    border-bottom: 2px solid;
    border-color: ${e=>e.secondary||"#fff"};
    bottom: 6px;
    left: 6px;
    height: 10px;
    width: 6px;
  }
`,Y=C("div")`
  position: absolute;
`,J=C("div")`
  position: relative;
  display: flex;
  justify-content: center;
  align-items: center;
  min-width: 20px;
  min-height: 20px;
`,X=C("div")`
  position: relative;
  transform: scale(0.6);
  opacity: 0.4;
  min-width: 20px;
  animation: ${E`
from {
  transform: scale(0.6);
  opacity: 0.4;
}
to {
  transform: scale(1);
  opacity: 1;
}`} 0.3s 0.12s cubic-bezier(0.175, 0.885, 0.32, 1.275)
    forwards;
`,G=({toast:e})=>{let{icon:t,type:a,iconTheme:s}=e;return void 0!==t?"string"==typeof t?d.createElement(X,null,t):t:"blank"===a?null:d.createElement(J,null,d.createElement(L,{...s}),"loading"!==a&&d.createElement(Y,null,"error"===a?d.createElement(B,{...s}):d.createElement(H,{...s})))},K=e=>`
0% {transform: translate3d(0,${-200*e}%,0) scale(.6); opacity:.5;}
100% {transform: translate3d(0,0,0) scale(1); opacity:1;}
`,Q=e=>`
0% {transform: translate3d(0,0,-1px) scale(1); opacity:1;}
100% {transform: translate3d(0,${-150*e}%,-1px) scale(.6); opacity:0;}
`,R=C("div")`
  display: flex;
  align-items: center;
  background: #fff;
  color: #363636;
  line-height: 1.3;
  will-change: transform;
  box-shadow: 0 3px 10px rgba(0, 0, 0, 0.1), 0 3px 3px rgba(0, 0, 0, 0.05);
  max-width: 350px;
  pointer-events: auto;
  padding: 8px 10px;
  border-radius: 8px;
`,U=C("div")`
  display: flex;
  justify-content: center;
  margin: 4px 10px;
  color: inherit;
  flex: 1 1 auto;
  white-space: pre-line;
`,V=(e,t)=>{let a=e.includes("top")?1:-1,[s,r]=z()?["0%{opacity:0;} 100%{opacity:1;}","0%{opacity:1;} 100%{opacity:0;}"]:[K(a),Q(a)];return{animation:t?`${E(s)} 0.35s cubic-bezier(.21,1.02,.73,1) forwards`:`${E(r)} 0.4s forwards cubic-bezier(.06,.71,.55,1)`}};d.memo(({toast:e,position:t,style:a,children:s})=>{let r=e.height?V(e.position||t||"top-center",e.visible):{opacity:0},i=d.createElement(G,{toast:e}),o=d.createElement(U,{...e.ariaProps},_(e.message,e));return d.createElement(R,{className:e.className,style:{...r,...a,...e.style}},"function"==typeof s?s({icon:i,message:o}):d.createElement(d.Fragment,null,i,o))}),i=d.createElement,h.p=void 0,w=i,v=void 0,k=void 0,N`
  z-index: 9999;
  > * {
    pointer-events: auto;
  }
`;let W=()=>{let[e,t]=(0,d.useState)({firstName:"",lastName:"",email:"",phoneNo:"",message:""}),[a,s]=(0,d.useState)(!1),r=a=>{t({...e,[a.target.name]:a.target.value})},i=t=>{t.preventDefault(),fetch("https://quikey-server.vercel.app/contact",{method:"POST",headers:{"content-type":"application/json"},body:JSON.stringify(e)}).then(e=>e.json()).then(e=>{console.log(e),s(!0),Z.success("Your message has been sent!")})};return(0,o.jsxs)(o.Fragment,{children:[(0,o.jsx)(l.Z,{}),(0,o.jsx)(c.E.div,{className:"bg-gray-300 lg:h-[83vh]",initial:{opacity:0},animate:{opacity:1},transition:{duration:1,delay:.5},exit:{opacity:0},children:(0,o.jsx)("div",{className:"flex flex-col justify-center text-white relative container mx-auto px-4 md:px-0 mb-24 h-full",children:(0,o.jsxs)("div",{className:"",children:[!a&&(0,o.jsxs)("div",{className:"text-center mb-8",children:[(0,o.jsx)("h2",{className:"text-4xl text-[#2B2C7F] font-bold mb-3",children:"Shoot an Email"}),(0,o.jsx)("p",{className:"text-[#2B2C7F]",children:"Any question or remarks? Just drop us a message!"})]}),(0,o.jsx)("div",{className:"flex justify-center items-center",children:(0,o.jsx)("div",{className:"bg-white p-4 lg:flex rounded-lg w-scee",children:a?(0,o.jsxs)("div",{className:"text-center w-full text-black border-2 border-orange-500 rounded-lg",children:[(0,o.jsx)("div",{className:"flex justify-center items-center",children:(0,o.jsx)("img",{src:"/image/53644-email-marketing-message-concept 1.png",className:"w-1/2",alt:""})}),(0,o.jsx)("h2",{className:"text-2xl font-bold mb-4",children:"Thank You!"}),(0,o.jsx)("p",{className:"mb-4",children:"Your message has been sent."})]}):(0,o.jsxs)(o.Fragment,{children:[(0,o.jsxs)("div",{className:"lg:w-1/3 relative",children:[(0,o.jsx)("img",{className:"w-full h-96 mb-10 lg:mb-0",src:"/image/Group 1000001809.png",alt:""}),(0,o.jsx)("h2",{className:"absolute top-5 left-4 text-2xl font-semibold",children:"Contact Information"}),(0,o.jsx)("h2",{className:"absolute bottom-5 left-4 text-md",children:"connect@mudslidecreatorshub.in"})]}),(0,o.jsxs)("form",{onSubmit:i,className:"px-4 lg:px-10 space-y-10",children:[(0,o.jsxs)("div",{className:"flex flex-col lg:flex-row gap-6",children:[(0,o.jsxs)("div",{className:" w-full max-w-xs",children:[(0,o.jsx)("label",{className:"",children:(0,o.jsxs)("span",{className:"text-gray-500 mb-8",children:["First name ",(0,o.jsx)("span",{className:"text-red-500",children:"*"})]})}),(0,o.jsx)("input",{onChange:r,name:"firstName",type:"text",className:"border-b border-gray-400 w-full max-w-xs ring-0 focus:outline-none text-black",required:!0})]}),(0,o.jsxs)("div",{className:" w-full max-w-xs",children:[(0,o.jsx)("label",{className:"",children:(0,o.jsxs)("span",{className:"text-gray-500 mb-8",children:["Last name ",(0,o.jsx)("span",{className:"text-red-500",children:"*"})]})}),(0,o.jsx)("input",{onChange:r,name:"lastName",type:"text",className:"border-b border-gray-400 w-full max-w-xs ring-0 focus:outline-none text-black",required:!0})]})]}),(0,o.jsxs)("div",{className:"flex flex-col lg:flex-row gap-6",children:[(0,o.jsxs)("div",{className:" w-full max-w-xs",children:[(0,o.jsx)("label",{className:"",children:(0,o.jsxs)("span",{className:"text-gray-500 mb-8",children:["Email ",(0,o.jsx)("span",{className:"text-red-500",children:"*"})]})}),(0,o.jsx)("input",{onChange:r,type:"text",name:"email",className:"border-b border-gray-400 w-full max-w-xs ring-0 focus:outline-none text-black",required:!0})]}),(0,o.jsxs)("div",{className:" w-full max-w-xs",children:[(0,o.jsx)("label",{className:"",children:(0,o.jsxs)("span",{className:"text-gray-500 mb-8",children:["Phone No."," "]})}),(0,o.jsx)("input",{onChange:r,name:"phoneNo",type:"text",className:"border-b border-gray-400 w-full max-w-xs ring-0 focus:outline-none text-black"})]})]}),(0,o.jsx)("div",{className:"",children:(0,o.jsxs)("div",{className:"flex flex-col w-full",children:[(0,o.jsx)("label",{className:"",children:(0,o.jsxs)("span",{className:"text-gray-500 mb-8",children:["Message ",(0,o.jsx)("span",{className:"text-red-500",children:"*"})]})}),(0,o.jsx)("textarea",{required:!0,onChange:r,name:"message",type:"text",className:"border-b border-gray-400 w-full ring-0 focus:outline-none text-black"})]})}),(0,o.jsx)("div",{className:"flex justify-end",children:(0,o.jsx)("button",{className:"btn bg-black text-white px-6 py-2 rounded-sm",children:"Send Message"})})]})]})})})]})})}),(0,o.jsx)(n.Z,{})]})};var ee=W}},function(e){e.O(0,[285,774,888,179],function(){return e(e.s=6008)}),_N_E=e.O()}]);