"use strict";
exports.id = 559;
exports.ids = [559];
exports.modules = {

/***/ 4559:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var firebase_app__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(3745);
/* harmony import */ var firebase_analytics__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9500);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([firebase_app__WEBPACK_IMPORTED_MODULE_0__, firebase_analytics__WEBPACK_IMPORTED_MODULE_1__]);
([firebase_app__WEBPACK_IMPORTED_MODULE_0__, firebase_analytics__WEBPACK_IMPORTED_MODULE_1__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);
// // Import the functions you need from the SDKs you need
// import { initializeApp } from "firebase/app";
// // import { getAnalytics } from "firebase/analytics";
// import firebase from "firebase/app";
// import "firebase/auth";
// import "firebase/firestore";
// // TODO: Add SDKs for Firebase products that you want to use
// // https://firebase.google.com/docs/web/setup#available-libraries
// // Your web app's Firebase configuration
// // For Firebase JS SDK v7.20.0 and later, measurementId is optional
// const firebaseConfig = {
//   apiKey: "AIzaSyDKf8N737_Tu1_r1AdqYKoIy5x9_HV7uQw",
//   authDomain: "mudslide-297d0.firebaseapp.com",
//   projectId: "mudslide-297d0",
//   storageBucket: "mudslide-297d0.appspot.com",
//   messagingSenderId: "370264612389",
//   appId: "1:370264612389:web:d066a21d4ea35d295929cc",
//   measurementId: "G-0Y7KJG753D",
// };
// let app;
// if (typeof window !== "undefined") {
//   // Initialize Firebase
//   app = initializeApp(firebaseConfig, "mudslide-297d0");
//   //   const analytics = getAnalytics(app);
// }
// export default app;
// Import the functions you need from the SDKs you need


// TODO: Add SDKs for Firebase products that you want to use
// https://firebase.google.com/docs/web/setup#available-libraries
// Your web app's Firebase configuration
// For Firebase JS SDK v7.20.0 and later, measurementId is optional
const firebaseConfig = {
    apiKey: "AIzaSyDKf8N737_Tu1_r1AdqYKoIy5x9_HV7uQw",
    authDomain: "mudslide-297d0.firebaseapp.com",
    projectId: "mudslide-297d0",
    storageBucket: "mudslide-297d0.appspot.com",
    messagingSenderId: "370264612389",
    appId: "1:370264612389:web:d066a21d4ea35d295929cc",
    measurementId: "G-0Y7KJG753D"
};
// Initialize Firebase
const app = (0,firebase_app__WEBPACK_IMPORTED_MODULE_0__.initializeApp)(firebaseConfig);
// const analytics = getAnalytics(app);
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (app);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;