const MessageItem = ({message}) => {
    console.log(message)
    return (
        <div className="w-full bg-gray-200">
            
        </div>
    )
}

export default MessageItem